package airlane;

import java.time.LocalTime;
import java.util.HashMap;
import java.util.concurrent.Semaphore;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.atomic.AtomicInteger;

public class ReaderThread implements Runnable{
    private final SharedResource Resource;
    private final String name;
    Semaphore readerMutex;
    Semaphore writerMutex;
    Semaphore in ;
    AtomicInteger readersCount;
    
    public ReaderThread(SharedResource Resource, String name) {
        this.Resource = Resource;
        this.name = name;
        in = new Semaphore(1);
        readerMutex = new Semaphore(1);
        writerMutex = new Semaphore(1);
        readersCount = new AtomicInteger(0);
    }
    public void run() {
        final String threadName = name + "(" + Thread.currentThread().getName() + ")";
        boolean running = true;
        while (running) {
            try {
                for (int i=1; i<Resource.placeCount();i++) {
                    Thread.sleep(ThreadLocalRandom.current().nextInt(3000));
                    read(threadName);
                }
            }
            catch (InterruptedException e) {
                running = false;
            }
        } 
    }
    public void read(String name) throws InterruptedException
	{       
                in.acquire();
                readerMutex.acquire(); //only one reader could modify writerMutex
            if (readersCount.incrementAndGet() == 1) {
                //the first reader that enters the critical section blocks all writers or waits until the writer has finished 
                writerMutex.acquire();
            }
            readerMutex.release();
            in.release();

            //[Critical Section]
		String time = "Time: " + LocalTime.now() +"\n";
		System.out.println(time + name + " observe the resource :");
		HashMap<Integer,String> s = Resource.Getplaces()  ;
		s.forEach((k,v) -> System.out.printf("Seat No " + k + ": " + v+ " "));
		System.out.println();
		System.out.println("-------------------------------------------------------------------------------");
		
		System.out.println();
                //[/Critical Section]
            
            readerMutex.acquire();
            if(readersCount.decrementAndGet() == 0) {
                //the last reader that leaves the critical section unblocks all writers
                writerMutex.release();
            }
            readerMutex.release();
	}
}
