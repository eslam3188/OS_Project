package airlane;

import java.time.LocalTime;
import java.util.concurrent.Semaphore;
import java.util.concurrent.ThreadLocalRandom;

public class WriterThread implements Runnable {
    private final SharedResource Resource;
    private final String name;
    Semaphore writerMutex;
    Semaphore in ;
    
    public WriterThread(SharedResource Resource, String name) {
        this.Resource = Resource;
        this.name = name;
        in = new Semaphore(1);
        writerMutex = new Semaphore(1);
    }
    
    @Override
    public void run() {
        final ThreadLocalRandom localRandom = ThreadLocalRandom.current();
        final String threadName = name + "(" + Thread.currentThread().getName() + ")";
        final long threadId = Thread.currentThread().getId();
        boolean running = true;
        while(running) {
            try {
                if (localRandom.nextInt(0, 9) < 7) {
                    // Write
                    Thread.sleep(localRandom.nextInt(3000));
                    Write(
                        threadName, 
                        localRandom.nextInt(1, 25),
                        threadId);
                } 
                else {
                    // Delete
                    Thread.sleep(localRandom.nextInt(3000));
                    Delete(
                        threadName,
                        localRandom.nextInt(1, 25),
                        threadId);
                }
            }
            catch (InterruptedException e) {
                running = false;
            }
            
        }
    }
    public void Write(String name, int placeNo, long customerId) throws InterruptedException
	{       
                in.acquire();
                writerMutex.acquire();
                //[Critical Section]
		String time = "Time: " + LocalTime.now() + "\n";
		System.out.println(time + name + " tries to Write " + placeNo + "\n");
		Thread.sleep(ThreadLocalRandom.current().nextInt(1000));
		if (Resource.Getplaces().containsKey(placeNo)) {
			if(Resource.Getplaces().get(placeNo) == "0") {
				System.out.println(time + name + " write done " + placeNo + " successfully\n");
				Resource.Getplaces().put(placeNo,String.valueOf(customerId));
			} 
			else {
				System.out.println(time + name + " could not write " + placeNo + " the place is occupied\n");
			}
		}
                //[Critical Section]
                writerMutex.release();
                in.release();
	}
	
	
	
	public void Delete(String name, int placeNo, long customerId) throws InterruptedException
	{   
                in.acquire();
                writerMutex.acquire();
                //[Critical Section]
		String time = "Time: " + LocalTime.now() +"\n";
		System.out.println(time + name + " tries to delete number " + placeNo + "\n");
		Thread.sleep(ThreadLocalRandom.current().nextInt(1000));
		if (Resource.Getplaces().containsKey(placeNo)) {
			if(Resource.Getplaces().get(placeNo) == String.valueOf(customerId)) {
				System.out.println(time + name + " number deleted " + placeNo + "\n");
				System.out.println();
				Resource.Getplaces().put(placeNo, "0");
			}
			else {
				System.out.println(time + name + " could not delete number " + placeNo + "\n");
			}
		} 
		//[Critical Section]
                writerMutex.release();
                in.release();
	}
}
