    package airlane;

import java.time.LocalTime;
import java.util.HashMap;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.AtomicInteger;    

public class Flight implements FlightBuffer{

	private final HashMap<Integer,String> seats;
        Semaphore readerMutex;
        Semaphore writerMutex;
        Semaphore in ;
        AtomicInteger readersCount;
	
	Flight()
	{
		this.seats = new HashMap<>();
		for(int i=1;i<=25;i++) this.seats.put(i,"0");
                in = new Semaphore(1);
                readerMutex = new Semaphore(1);
                writerMutex = new Semaphore(1);
                readersCount = new AtomicInteger(0);
		
	}
	
	@Override
	public void queryReservation(String name) throws InterruptedException
	{       
                in.acquire();
                readerMutex.acquire(); //only one reader could modify writerMutex
            if (readersCount.incrementAndGet() == 1) {
                //the first reader that enters the critical section blocks all writers or waits until the writer has finished 
                writerMutex.acquire();
            }
            readerMutex.release();
            in.release();

            //[Critical Section]
		String time = "Time: " + LocalTime.now() +"\n";
		System.out.println(time + name + " looks for avaiblable seats.State of the seats are :");
		HashMap<Integer,String> s = this.seats;
		s.forEach((k,v) -> System.out.printf("Seat No " + k + ": " + v+ " "));
		System.out.println();
		System.out.println("-------------------------------------------------------------------------------");
		
		System.out.println();
                //[/Critical Section]
            
            readerMutex.acquire();
            if(readersCount.decrementAndGet() == 0) {
                //the last reader that leaves the critical section unblocks all writers
                writerMutex.release();
            }
            readerMutex.release();
	}
	
	@Override
	public void makeReservation(String name, int seatNo, long customerId) throws InterruptedException
	{       
                in.acquire();
                writerMutex.acquire();
                //[Critical Section]
		String time = "Time: " + LocalTime.now() + "\n";
		System.out.println(time + name + " tries to book the seat " + seatNo + "\n");
		Thread.sleep(ThreadLocalRandom.current().nextInt(1000));
		if (this.seats.containsKey(seatNo)) {
			if(this.seats.get(seatNo) == "0") {
				System.out.println(time + name + " booked seat number " + seatNo + " successfully\n");
				this.seats.put(seatNo,String.valueOf(customerId));
			} 
			else {
				System.out.println(time + name + " could not book seat number " + seatNo + " since it has been already booked\n");
			}
		}
                //[Critical Section]
                writerMutex.release();
                in.release();
	}
	
	
	@Override
	public void cancelReservation(String name, int seatNo, long customerId) throws InterruptedException
	{   
                in.acquire();
                writerMutex.acquire();
                //[Critical Section]
		String time = "Time: " + LocalTime.now() +"\n";
		System.out.println(time + name + " tries to cancel book the seat " + seatNo + "\n");
		Thread.sleep(ThreadLocalRandom.current().nextInt(1000));
		if (this.seats.containsKey(seatNo)) {
			if(this.seats.get(seatNo) == String.valueOf(customerId)) {
				System.out.println(time + name + " canceled seat number " + seatNo + "\n");
				System.out.println();
				this.seats.put(seatNo, "0");
			}
			else {
				System.out.println(time + name + " could not cancel seat number " + seatNo + "\n");
			}
		} 
		//[Critical Section]
                writerMutex.release();
                in.release();
	}

	@Override
	public void cancelAll() {
		for(int i=1;i<=5;i++) this.seats.put(i,"0");
		String time = "Time: " + LocalTime.now() +"\n";
		System.out.println(time + "All reservations on the flight are cancelled!\n");
	}
	
	@Override
	public int seatCount() {
		return this.seats.size();
	}

}

    
